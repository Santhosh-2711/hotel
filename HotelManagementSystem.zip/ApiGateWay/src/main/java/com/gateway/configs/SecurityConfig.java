package com.gateway.configs;

import com.gateway.filters.JwtAuthenticationFilter;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.web.server.ServerHttpSecurity;
import org.springframework.security.config.web.server.SecurityWebFiltersOrder;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.MapReactiveUserDetailsService;
import org.springframework.security.web.server.SecurityWebFilterChain;

@Configuration
public class SecurityConfig {

    private final JwtAuthenticationFilter jwtAuthenticationFilter;

    public SecurityConfig(JwtAuthenticationFilter jwtAuthenticationFilter) {
        this.jwtAuthenticationFilter = jwtAuthenticationFilter;
    }

    @Bean
    public SecurityWebFilterChain securityWebFilterChain(ServerHttpSecurity http) {
        return http
            .csrf(ServerHttpSecurity.CsrfSpec::disable)
            .authorizeExchange(exchange -> exchange
                .pathMatchers("/auth/**").permitAll()
                .pathMatchers("/rms/**").hasAnyAuthority("ROLE_OWNER","ROLE_MANAGER","ROLE_RECEPTIONIST")
                .pathMatchers("/sms/**").hasAnyAuthority("ROLE_OWNER","ROLE_MANAGER")
                .pathMatchers("/booking/**", "/guest/**").hasAnyAuthority("ROLE_RECEPTIONIST","ROLE_OWNER")
                .pathMatchers("/billing/**").hasAnyAuthority("ROLE_RECEPTIONIST", "ROLE_OWNER")
                .pathMatchers("/setprices/**").hasAuthority("ROLE_OWNER")
                .anyExchange().authenticated()
            )
            .addFilterAt(jwtAuthenticationFilter, SecurityWebFiltersOrder.AUTHENTICATION)
            .build();
    }

    @Bean
     MapReactiveUserDetailsService userDetailsService() {
        UserDetails owner = User.withUsername("owner")
            .password("{noop}Owner@123") 
            .roles("OWNER")  
            .build();
        
        UserDetails manager = User.withUsername("manager")
            .password("{noop}Manager@123")
            .roles("MANAGER")  
            .build();
        
        UserDetails receptionist = User.withUsername("reception")
            .password("{noop}Reception@123")
            .roles("RECEPTIONIST")  
            .build();
        
        return new MapReactiveUserDetailsService(owner, manager, receptionist);
    }
}
