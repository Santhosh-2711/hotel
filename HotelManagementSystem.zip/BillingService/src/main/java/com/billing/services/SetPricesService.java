package com.billing.services;

import java.util.List;

import com.billing.entities.SetPrices;


public interface SetPricesService {
	
	SetPrices add(SetPrices setPrices);
	
	List<SetPrices> get();
	
	SetPrices getOne(String id);
	
	void delete(SetPrices setPrices);

	
	

}
