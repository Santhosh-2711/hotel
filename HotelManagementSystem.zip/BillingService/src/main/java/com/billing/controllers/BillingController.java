package com.billing.controllers;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.billing.client.BookingClient;
import com.billing.client.RoomClient;
import com.billing.entities.Billing;
import com.billing.entities.Booking;
import com.billing.entities.RoomManagement;
import com.billing.entities.SetPrices;
import com.billing.services.BillingService;
import com.billing.services.SetPricesService;

@RestController
@RequestMapping("/billing")
public class BillingController {
	
	@Autowired
	private BillingService billingService;
	@Autowired
	private RoomClient roomClient;
	@Autowired
	private SetPricesService setPricesService;
	@Autowired
	private BookingClient bookingClient;
	

	@PostMapping
	public Billing create(@RequestBody Billing billing) {
		
		RoomManagement roomManagement = roomClient.getRoomtype(billing.getRoomnumber());
		String roomtype = roomManagement.getRoomtype();
		
		SetPrices setPrices = setPricesService.getOne(roomtype);
		Integer price = setPrices.getPrice();
		
		Booking booking = bookingClient.getBookingById(billing.getBookId());
		Integer noOfNights = booking.getNoofnights();
		
		Integer tax = (billing.getTax() * price * noOfNights) / 100;
		Integer total = (price * noOfNights)+tax+billing.getServices();
		
		Billing billing2 = new Billing();
		billing2.setRoomnumber(billing.getRoomnumber());
		billing2.setBookId(billing.getBookId());
		billing2.setNoofnights(noOfNights);
		billing2.setPrice(price);
		billing2.setTax(tax);
		billing2.setBilldate(LocalDate.now());
		billing2.setServices(billing.getServices());
		billing2.setTotal(total);
		return billingService.add(billing2);
	}
	
	@GetMapping
	public List<Billing> getAll(){
		return billingService.get();
	}
	
	@GetMapping("/{billno}")
	public Billing getAll(@PathVariable Long billno) {
		return billingService.getOne(billno);
	}
	
	@PutMapping("/{billno}")
	public Billing updateBill(@PathVariable Long billno, @RequestBody Billing billing) {
		
	    Billing change = billingService.getOne(billno);
	    Booking booking = bookingClient.getBookingById(change.getBookId());
		Integer noOfNights = booking.getNoofnights();
	    change.setTax(billing.getTax());
	    change.setServices(billing.getServices());
	    change.setNoofnights(noOfNights);
	    
	    Integer tax = (change.getTax() * change.getPrice() * change.getNoofnights()) / 100;
	    Integer total = (change.getPrice() * change.getNoofnights()) + tax + change.getServices();
	    
	    change.setTax(tax);
	    change.setTotal(total);
	    return billingService.add(change); 
	}

	
	@DeleteMapping("/delete/{billno}")
	public String removeBill(@PathVariable Long billno) {
		Billing bill = billingService.getOne(billno);
		billingService.delete(bill);
		return "Bill deleted Successfully";
	}

}
