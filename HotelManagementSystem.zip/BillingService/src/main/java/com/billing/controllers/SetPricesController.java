package com.billing.controllers;

import java.util.List;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.billing.entities.SetPrices;
import com.billing.services.SetPricesService;

@RestController
@RequestMapping("/setprices")
public class SetPricesController {
	
	private SetPricesService setPricesService;

	public SetPricesController(SetPricesService setPricesService) {
		super();
		this.setPricesService = setPricesService;
	}
	
	@PostMapping
	public SetPrices create(@RequestBody SetPrices setPrices) {
		return setPricesService.add(setPrices);
	}
	
	@GetMapping
	public List<SetPrices> getAll(){
		return setPricesService.get();
	}
	
	@GetMapping("/{roomtype}" )
	public SetPrices getAll(@PathVariable String roomtype) {
		return setPricesService.getOne(roomtype);
	}
	
	@PutMapping("/{roomtype}")
	public SetPrices updatePrices(@PathVariable String roomtype,@RequestBody SetPrices setPrices) {
		SetPrices change =  setPricesService.getOne(roomtype);
		
		change.setPrice(setPrices.getPrice());
		return setPricesService.add(change);
		
	}
	
	@DeleteMapping("delete/{roomtype}")
	public String removePrice(@PathVariable String roomtype) {
		SetPrices price = setPricesService.getOne(roomtype);
	    setPricesService.delete(price);
	    return "Price deleted Successfully";
	}

}
