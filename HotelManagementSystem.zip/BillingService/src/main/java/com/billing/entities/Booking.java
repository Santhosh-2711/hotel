package com.billing.entities;

public class Booking {

	private Integer roomnumber;
	private Integer noofnights;

	
	public Integer getRoomnumber() {
		return roomnumber;
	}
	public void setRoomnumber(Integer roomnumber) {
		this.roomnumber = roomnumber;
	}
	public Integer getNoofnights() {
		return noofnights;
	}
	public void setNoofnights(Integer noofnights) {
		this.noofnights = noofnights;
	}
public Booking() {
		
	}



public Booking(Integer roomnumber, Integer noofnights) {
	super();
	this.roomnumber = roomnumber;
	this.noofnights = noofnights;
}

	

	
	
}
