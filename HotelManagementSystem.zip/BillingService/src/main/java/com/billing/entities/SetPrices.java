package com.billing.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class SetPrices {
	
	@Id
	private String roomtype;
	
	private Integer price;
	
	public SetPrices() {
		
	}
	
	public SetPrices(String roomtype, Integer price) {
		super();
		this.roomtype = roomtype;
		this.price = price;
	}
	public String getRoomtype() {
		return roomtype;
	}
	public void setRoomtype(String roomtype) {
		this.roomtype = roomtype;
	}
	public Integer getPrice() {
		return price;
	}
	public void setPrice(Integer price) {
		this.price = price;
	}
	
	

}
