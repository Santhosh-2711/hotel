package com.billing.entities;



public class RoomManagement {
	
	private int roomnumber;
	
	private String roomtype;
	
	public RoomManagement() {
		
	}
	
	public RoomManagement(int roomnumber, String roomtype) {
		super();
		this.roomnumber = roomnumber;
		this.roomtype = roomtype;
	}
	
	
	public int getRoomnumber() {
		return roomnumber;
	}
	public void setRoomnumber(int roomnumber) {
		this.roomnumber = roomnumber;
	}
	public String getRoomtype() {
		return roomtype;
	}

	public void setRoomtype(String roomtype) {
		this.roomtype = roomtype;
	}	
	
}
