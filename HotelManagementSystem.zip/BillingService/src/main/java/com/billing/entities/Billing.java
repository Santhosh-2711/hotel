package com.billing.entities;

import java.time.LocalDate;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Billing {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long billno;
    
    private Long bookId;
    private Integer roomnumber;
    private Integer noofnights;
    private Integer price;
    private Integer tax;
    private LocalDate billdate;
    private Integer services;
    private Integer total;

    public Billing() {
    }

    

    public Billing(Long billno, Long bookId, Integer roomnumber, Integer noofnights, Integer price, Integer tax,
			LocalDate billdate, Integer services, Integer total) {
		super();
		this.billno = billno;
		this.bookId = bookId;
		this.roomnumber = roomnumber;
		this.noofnights = noofnights;
		this.price = price;
		this.tax = tax;
		this.billdate = billdate;
		this.services = services;
		this.total = total;
	}



	// Getters and setters

    public Long getBillno() {
        return billno;
    }

    public void setBillno(Long billno) {
        this.billno = billno;
    }

    public Integer getRoomnumber() {
        return roomnumber;
    }

    public void setRoomnumber(Integer roomnumber) {
        this.roomnumber = roomnumber;
    }

    public Integer getNoofnights() {
        return noofnights;
    }

    public void setNoofnights(Integer noofnights) {
        this.noofnights = noofnights;
    }

    public Integer getPrice() {
        return price;
    }

    public void setPrice(Integer price) {
        this.price = price;
    }

    public Integer getTax() {
        return tax;
    }

    public void setTax(Integer tax) {
        this.tax = tax;
    }

    public LocalDate getBilldate() {
        return billdate;
    }

    public void setBilldate(LocalDate billdate) {
        this.billdate = billdate;
    }

    public Integer getServices() {
        return services;
    }

    public void setServices(Integer services) {
        this.services = services;
    }

    public Integer getTotal() {
        return total;
    }

    public void setTotal(Integer total) {
        this.total = total;
    }
	public Long getBookId() {
		return bookId;
	}
	public void setBookId(Long bookId) {
		this.bookId = bookId;
	}

    
}
