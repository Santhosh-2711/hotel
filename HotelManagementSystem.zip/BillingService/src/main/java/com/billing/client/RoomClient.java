package com.billing.client;


import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.billing.entities.RoomManagement;

@FeignClient(name = "ROOMMANAGEMENTSYSTEM")
//@FeignClient(name = "ROOMMANAGEMENTSYSTEM", url ="http://localhost:9091" )
public interface RoomClient {
	
	@GetMapping("/rms/{roomnumber}")
	RoomManagement getRoomtype(@PathVariable("roomnumber") Integer roomnumber);

}
