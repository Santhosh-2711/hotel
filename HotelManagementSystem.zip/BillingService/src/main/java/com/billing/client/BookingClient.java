package com.billing.client;


import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.billing.entities.Booking;

@FeignClient(name = "BOOKINGSERVICE")
//@FeignClient(name = "BOOKINGSERVICE", url ="http://localhost:9093/" )
public interface BookingClient {
	
	@GetMapping("/booking/{id}")
	Booking getBookingById(@PathVariable("id") Long bookId);

}
