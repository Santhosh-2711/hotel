package com.billing.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.billing.entities.SetPrices;

public interface SetPricesRepository extends JpaRepository<SetPrices, String>{

}
