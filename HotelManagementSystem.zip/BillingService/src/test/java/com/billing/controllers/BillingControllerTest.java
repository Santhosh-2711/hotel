package com.billing.controllers;

import com.billing.entities.Billing;
import com.billing.entities.Booking;
import com.billing.entities.RoomManagement;
import com.billing.entities.SetPrices;
import com.billing.services.BillingService;
import com.billing.services.SetPricesService;
import com.billing.client.BookingClient;
import com.billing.client.RoomClient;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

import java.time.LocalDate;
import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

class BillingControllerTest {

    @InjectMocks
    private BillingController billingController;

    @Mock
    private BillingService billingService;

    @Mock
    private RoomClient roomClient;

    @Mock
    private SetPricesService setPricesService;

    @Mock
    private BookingClient bookingClient;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void createBillingTest() {
        Billing billing = new Billing();
        billing.setRoomnumber(105);
        billing.setBookId(1L);
        billing.setTax(18);
        billing.setServices(800);

        RoomManagement roomManagement = new RoomManagement(105, "Deluxe");
        when(roomClient.getRoomtype(105)).thenReturn(roomManagement);

        SetPrices setPrices = new SetPrices("Deluxe", 1000);
        when(setPricesService.getOne("Deluxe")).thenReturn(setPrices);

        Booking booking = new Booking();
        booking.setNoofnights(2);
        when(bookingClient.getBookingById(1L)).thenReturn(booking);

        Billing savedBilling = new Billing();
        savedBilling.setBillno(1L);
        savedBilling.setBookId(1L);
        savedBilling.setRoomnumber(105);
        savedBilling.setNoofnights(2);
        savedBilling.setPrice(1000);
        savedBilling.setTax(300);
        savedBilling.setBilldate(LocalDate.now());
        savedBilling.setServices(1200);
        savedBilling.setTotal(3500);
        when(billingService.add(any(Billing.class))).thenReturn(savedBilling);

        Billing result = billingController.create(billing);

        assertNotNull(result);
        assertEquals(3500, result.getTotal());
        assertEquals(300, result.getTax());
        assertEquals(1200, result.getServices());
        assertEquals(2, result.getNoofnights());
        assertEquals(105, result.getRoomnumber());
        assertEquals(1L, result.getBookId());
        verify(billingService, times(1)).add(any(Billing.class));
    }



    @Test
    void getAllBillsTest() {
        billingController.getAll();
        verify(billingService, times(1)).get();
    }

    @Test
    void getBillByIdTest() {
        Billing billing = new Billing();
        when(billingService.getOne(1L)).thenReturn(billing);
        Billing result = billingController.getAll(1L);
        assertNotNull(result);
        verify(billingService, times(1)).getOne(1L);
    }

    @Test
    void updateBillTest() {
        Billing existingBilling = new Billing();
        existingBilling.setPrice(500);
        existingBilling.setNoofnights(2);
        when(billingService.getOne(1L)).thenReturn(existingBilling);

        Billing updatedBilling = new Billing();
        updatedBilling.setTax(10);
        updatedBilling.setServices(50);

        Billing savedBilling = new Billing();
        savedBilling.setTotal(600);
        when(billingService.add(any(Billing.class))).thenReturn(savedBilling);

        Billing result = billingController.updateBill(1L, updatedBilling);
        assertNotNull(result);
        assertEquals(600, result.getTotal());
        verify(billingService, times(1)).add(any(Billing.class));
    }

    @Test
    void removeBillTest() {
        Billing billing = new Billing();
        when(billingService.getOne(1L)).thenReturn(billing);
        billingController.removeBill(1L);
        verify(billingService, times(1)).delete(billing);
    }
}
