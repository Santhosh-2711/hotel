package com.billing.controllers;

import com.billing.entities.SetPrices;
import com.billing.services.SetPricesService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

class SetPricesControllerTest {

    @InjectMocks
    private SetPricesController setPricesController;

    @Mock
    private SetPricesService setPricesService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void createSetPricesTest() {
        SetPrices setPrices = new SetPrices("Deluxe", 500);
        when(setPricesService.add(setPrices)).thenReturn(setPrices);

        SetPrices result = setPricesController.create(setPrices);
        assertNotNull(result);
        assertEquals(500, result.getPrice());
        verify(setPricesService, times(1)).add(setPrices);
    }

    @Test
    void getAllSetPricesTest() {
        setPricesController.getAll();
        verify(setPricesService, times(1)).get();
    }

    @Test
    void getSetPriceByRoomTypeTest() {
        SetPrices setPrices = new SetPrices("Deluxe", 500);
        when(setPricesService.getOne("Deluxe")).thenReturn(setPrices);

        SetPrices result = setPricesController.getAll("Deluxe");
        assertNotNull(result);
        assertEquals(500, result.getPrice());
        verify(setPricesService, times(1)).getOne("Deluxe");
    }

    @Test
    void updateSetPriceTest() {
        SetPrices setPrices = new SetPrices("Deluxe", 500);
        when(setPricesService.getOne(any(String.class))).thenReturn(setPrices);

        SetPrices updatedSetPrices = new SetPrices("Deluxe", 2000);
        when(setPricesService.add(any(SetPrices.class))).thenReturn(updatedSetPrices);

        SetPrices result = setPricesController.updatePrices("Deluxe", updatedSetPrices);

        assertNotNull(result);
        assertEquals(2000, result.getPrice());
        verify(setPricesService, times(1)).add(any(SetPrices.class));
    }




    @Test
    void removeSetPriceTest() {
        SetPrices setPrices = new SetPrices("Deluxe", 500);
        when(setPricesService.getOne("Deluxe")).thenReturn(setPrices);

        setPricesController.removePrice("Deluxe");
        verify(setPricesService, times(1)).delete(setPrices);
    }
}
