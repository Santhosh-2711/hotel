package com.billing.services.impl;

import com.billing.entities.Billing;
import com.billing.repositories.BillingRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

class BillingServiceImplTest {

    @InjectMocks
    private BillingServiceImpl billingService;

    @Mock
    private BillingRepository billingRepository;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void addBillingTest() {
        Billing billing = new Billing();
        when(billingRepository.save(billing)).thenReturn(billing);

        Billing savedBilling = billingService.add(billing);

        assertNotNull(savedBilling);
        verify(billingRepository, times(1)).save(billing);
    }

    @Test
    void getAllBillsTest() {
        billingService.get();
        verify(billingRepository, times(1)).findAll();
    }

    @Test
    void getBillByIdTest() {
        Billing billing = new Billing();
        when(billingRepository.findById(1L)).thenReturn(java.util.Optional.of(billing));

        Billing result = billingService.getOne(1L);
        assertNotNull(result);
        verify(billingRepository, times(1)).findById(1L);
    }

    @Test
    void deleteBillTest() {
        Billing billing = new Billing();
        billingService.delete(billing);
        verify(billingRepository, times(1)).delete(billing);
    }
}
