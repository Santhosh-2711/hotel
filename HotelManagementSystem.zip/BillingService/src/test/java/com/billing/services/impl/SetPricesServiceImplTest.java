package com.billing.services.impl;

import com.billing.entities.SetPrices;
import com.billing.repositories.SetPricesRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

class SetPricesServiceImplTest {

    @InjectMocks
    private SetPricesServiceImpl setPricesService;

    @Mock
    private SetPricesRepository setPricesRepository;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void addSetPriceTest() {
        SetPrices setPrices = new SetPrices("Deluxe", 500);
        when(setPricesRepository.save(setPrices)).thenReturn(setPrices);

        SetPrices savedSetPrices = setPricesService.add(setPrices);
        assertNotNull(savedSetPrices);
        assertEquals(500, savedSetPrices.getPrice());
        verify(setPricesRepository, times(1)).save(setPrices);
    }

    @Test
    void getAllSetPricesTest() {
        setPricesService.get();
        verify(setPricesRepository, times(1)).findAll();
    }

    @Test
    void getSetPriceByRoomTypeTest() {
        SetPrices setPrices = new SetPrices("Deluxe", 500);
        when(setPricesRepository.findById("Deluxe")).thenReturn(java.util.Optional.of(setPrices));

        SetPrices result = setPricesService.getOne("Deluxe");
        assertNotNull(result);
        assertEquals(500, result.getPrice());
        verify(setPricesRepository, times(1)).findById("Deluxe");
    }

    @Test
    void deleteSetPriceTest() {
        SetPrices setPrices = new SetPrices("Deluxe", 500);
        setPricesService.delete(setPrices);
        verify(setPricesRepository, times(1)).delete(setPrices);
    }

    @Test
    void getSetPriceByRoomTypeNotFoundTest() {
        when(setPricesRepository.findById("Standard")).thenReturn(java.util.Optional.empty());

        Exception exception = assertThrows(RuntimeException.class, () -> setPricesService.getOne("Standard"));
        assertEquals("Price not found", exception.getMessage());
        verify(setPricesRepository, times(1)).findById("Standard");
    }
}
