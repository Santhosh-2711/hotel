package com.booking.services.impl;

import java.time.LocalDate;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.booking.client.RoomClient;
import com.booking.entities.Booking;
import com.booking.entities.RoomManagement;
import com.booking.repositories.BookingRepository;
import com.booking.services.BookingService;

import jakarta.transaction.Transactional;

@Service
public class BookingServiceImpl implements BookingService {

    private static Logger logger = LoggerFactory.getLogger(BookingServiceImpl.class);

    private BookingRepository bookingRepository;
    private RoomClient roomClient;

    public BookingServiceImpl(BookingRepository bookingRepository, RoomClient roomClient) {
        this.bookingRepository = bookingRepository;
        this.roomClient = roomClient;
    }

    @Override
    @Transactional
    public Booking add(Booking booking) {
        logger.info("Request received to add Booking: {}", booking);
        try {
            Booking savedBooking = bookingRepository.save(booking);
            
            if ("completed".equalsIgnoreCase(booking.getStatus())) {
                RoomManagement roomManagement = new RoomManagement();
                roomManagement.setRoomoccupancy("Occupied");
                
                logger.info("Updating room occupancy for room number: {}", booking.getRoomnumber());
                roomClient.updateRoomOccupancy(booking.getRoomnumber(), roomManagement);
            }
            logger.info("Booking saved successfully: {}", savedBooking);
            return savedBooking;
        } catch (Exception e) {
            logger.error("Error occurred while adding Booking: {}", e.getMessage(), e);
            throw new RuntimeException("Failed to add Booking", e);
        }
    }

    @Override
    public List<Booking> get() {
        logger.info("Fetching all Booking entries");
        try {
            List<Booking> bookings = bookingRepository.findAll();
            logger.info("Fetched {} Booking entries", bookings.size());
            return bookings;
        } catch (Exception e) {
            logger.error("Error occurred while fetching Booking entries: {}", e.getMessage(), e);
            throw new RuntimeException("Failed to fetch Booking entries", e);
        }
    }

    @Override
    public Booking getOne(Long id) {
        logger.info("Fetching Booking entry with id: {}", id);
        try {
            Booking booking = bookingRepository.findById(id).orElseThrow(() -> new RuntimeException("Booking not found"));
            logger.info("Fetched Booking entry: {}", booking);
            return booking;
        } catch (Exception e) {
            logger.error("Error occurred while fetching Booking with id {}: {}", id, e.getMessage(), e);
            throw new RuntimeException("Booking not found", e);
        }
    }

    @Override
    public void delete(Booking booking) {
        logger.info("Request received to delete Booking: {}", booking);
        try {
            bookingRepository.delete(booking);
            logger.info("Booking deleted successfully: {}", booking);
        } catch (Exception e) {
            logger.error("Error occurred while deleting Booking: {}", e.getMessage(), e);
            throw new RuntimeException("Failed to delete Booking", e);
        }
    }

    @Override
    public List<Booking> getBookingsofcheckindate(LocalDate checkindate) {
        logger.info("Fetching Booking entries with check-in date: {}", checkindate);
        try {
            List<Booking> bookings = bookingRepository.findByCheckindate(checkindate);
            logger.info("Fetched {} Booking entries for check-in date: {}", bookings.size(), checkindate);
            return bookings;
        } catch (Exception e) {
            logger.error("Error occurred while fetching Booking entries for check-in date {}: {}", checkindate, e.getMessage(), e);
            throw new RuntimeException("Failed to fetch Booking entries for check-in date", e);
        }
    }

    @Override
    public List<Booking> getBookingsofcheckoutdate(LocalDate checkoutdate) {
        logger.info("Fetching Booking entries with check-out date: {}", checkoutdate);
        try {
            List<Booking> bookings = bookingRepository.findByCheckoutdate(checkoutdate);
            logger.info("Fetched {} Booking entries for check-out date: {}", bookings.size(), checkoutdate);
            return bookings;
        } catch (Exception e) {
            logger.error("Error occurred while fetching Booking entries for check-out date {}: {}", checkoutdate, e.getMessage(), e);
            throw new RuntimeException("Failed to fetch Booking entries for check-out date", e);
        }
    }

    @Override
    public List<Booking> getBookingsofnoofnights(Integer noofnights) {
        logger.info("Fetching Booking entries with number of nights: {}", noofnights);
        try {
            List<Booking> bookings = bookingRepository.findByNoofnights(noofnights);
            logger.info("Fetched {} Booking entries for {} nights", bookings.size(), noofnights);
            return bookings;
        } catch (Exception e) {
            logger.error("Error occurred while fetching Booking entries for {} nights: {}", noofnights, e.getMessage(), e);
            throw new RuntimeException("Failed to fetch Booking entries for number of nights", e);
        }
    }

    @Override
    public List<Booking> getByGuestid(Long guestId) {
        logger.info("Fetching Booking entries for Guest ID: {}", guestId);
        try {
            List<Booking> bookings = bookingRepository.findByGuest_GuestId(guestId);
            logger.info("Fetched {} Booking entries for Guest ID: {}", bookings.size(), guestId);
            return bookings;
        } catch (Exception e) {
            logger.error("Error occurred while fetching Booking entries for Guest ID {}: {}", guestId, e.getMessage(), e);
            throw new RuntimeException("Failed to fetch Booking entries for Guest ID", e);
        }
    }

    @Override
    public List<Booking> getByRoom(int roomnumber) {
        logger.info("Fetching Booking entries for Room number: {}", roomnumber);
        try {
            List<Booking> bookings = bookingRepository.findByRoomnumber(roomnumber);
            logger.info("Fetched {} Booking entries for Room number: {}", bookings.size(), roomnumber);
            return bookings;
        } catch (Exception e) {
            logger.error("Error occurred while fetching Booking entries for Room number {}: {}", roomnumber, e.getMessage(), e);
            throw new RuntimeException("Failed to fetch Booking entries for Room number", e);
        }
    }
}
