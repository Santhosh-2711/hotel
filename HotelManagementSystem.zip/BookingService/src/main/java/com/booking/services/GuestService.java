package com.booking.services;

import java.util.List;

import com.booking.entities.Guest;

public interface GuestService {
	
	Guest add(Guest guest);
	
	List<Guest> get();
	
	Guest getOne(Long id);
	
	void delete(Guest guest);

}
