package com.booking.services;

import java.time.LocalDate;
import java.util.List;

import com.booking.entities.Booking;

public interface BookingService {
	
    Booking add(Booking booking);
	
	List<Booking> get();
	
	Booking getOne(Long id);
	
	List<Booking> getBookingsofcheckindate(LocalDate checkindate);
	
	List<Booking> getBookingsofcheckoutdate(LocalDate checkoutdate);
	
	List<Booking> getBookingsofnoofnights(Integer noofnights);
	
	void delete(Booking booking);

	List<Booking> getByGuestid(Long guestId);
	
	List<Booking> getByRoom(int roomnumber);

}
