package com.booking.services.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.booking.entities.Guest;
import com.booking.repositories.GuestRepository;
import com.booking.services.GuestService;

@Service
public class GuestServiceImpl implements GuestService {
    
    private static Logger logger = LoggerFactory.getLogger(GuestServiceImpl.class);
    
    private GuestRepository guestRepository;

    public GuestServiceImpl(GuestRepository guestRepository) {
        this.guestRepository = guestRepository;
    }

    @Override
    public Guest add(Guest guest) {
        logger.info("Request received to add Guest: {}", guest);
        try {
            Guest savedGuest = guestRepository.save(guest);
            logger.info("Guest added successfully: {}", savedGuest);
            return savedGuest;
        } catch (Exception e) {
            logger.error("Error occurred while adding Guest: {}", e.getMessage(), e);
            return null;
        }
    }

    @Override
    public List<Guest> get() {
        logger.info("Fetching all Guest entries");
        try {
            List<Guest> guests = guestRepository.findAll();
            logger.info("Fetched {} Guest entries", guests.size());
            return guests;
        } catch (Exception e) {
            logger.error("Error occurred while fetching Guest entries: {}", e.getMessage(), e);
            return null;
        }
    }

    @Override
    public Guest getOne(Long id) {
        logger.info("Fetching Guest entry with id: {}", id);
        try {
            Guest guest = guestRepository.findById(id).orElseThrow();
            logger.info("Fetched Guest entry: {}", guest);
            return guest;
        } catch (Exception e) {
            logger.error("Error occurred while fetching Guest with id {}: {}", id, e.getMessage(), e);
            return null;
        }
    }

    @Override
    public void delete(Guest guest) {
        logger.info("Request received to delete Guest: {}", guest);
        try {
            guestRepository.delete(guest);
            logger.info("Guest deleted successfully: {}", guest);
        } catch (Exception e) {
            logger.error("Error occurred while deleting Guest: {}", e.getMessage(), e);
        }
    }
}
