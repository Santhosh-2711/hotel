package com.booking.client;


import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;

import com.booking.entities.RoomManagement;

@FeignClient(name = "ROOMMANAGEMENTSYSTEM")
//@FeignClient(name = "ROOMMANAGEMENTSYSTEM", url ="http://localhost:9091" )
public interface RoomClient {
	
	
	
	@PutMapping("/rms/{roomnumber}")
	RoomManagement updateRoomOccupancy(@PathVariable("roomnumber") Integer roomnumber, RoomManagement roomMangement);

}
