package com.booking.controllers;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.booking.entities.Booking;
import com.booking.services.BookingService;

@RestController
@RequestMapping("/booking")
public class BookingController {
	
	@Autowired
	private BookingService bookingService;
	
	public BookingController(BookingService bookingService) {
		super();
		this.bookingService = bookingService;
	}

	@PostMapping
	public Booking create(@RequestBody Booking booking) {
		return bookingService.add(booking);
	}
	
	@GetMapping
	public List<Booking> getAll(){
		return bookingService.get();
	}
	
	@GetMapping("/{id}")
	public Booking getAll(@PathVariable Long id) {
		return bookingService.getOne(id);
	}
	
	@PutMapping("/{id}")
	public Booking updateBooking(@PathVariable Long id, @RequestBody Booking booking) {
		Booking change = bookingService.getOne(id);
		change.setNoofChildren(booking.getNoofChildren());
		change.setNoofAdults(booking.getNoofAdults());
		change.setCheckindate(booking.getCheckindate());
		change.setCheckoutdate(booking.getCheckoutdate());
		change.setStatus(booking.getStatus());
		
		return bookingService.add(change);
	}
	
	@DeleteMapping("/delete/{id}")
	public String removebooking(@PathVariable Long id) {
		Booking booking = bookingService.getOne(id);
		bookingService.delete(booking);
	    return "Booking deleted Successfully";
	}
	
	@GetMapping("/check_in/{checkindate}")
	public List<Booking> getBookingsofcheckindate(@PathVariable LocalDate checkindate){
		return bookingService.getBookingsofcheckindate(checkindate);
	}
	
	@GetMapping("/check_out/{checkoutdate}")
	public List<Booking> getBookingsofcheckoutdate(@PathVariable LocalDate checkoutdate){
		return bookingService.getBookingsofcheckoutdate(checkoutdate);
	}
	
	@GetMapping("/period/{noofnights}")
	public List<Booking> getBookingsofnoofnights(@PathVariable Integer noofnights){
		return bookingService.getBookingsofnoofnights(noofnights);
	}
	
	@GetMapping("/guest/{guestId}")
	public List<Booking> getByGuestid(@PathVariable Long guestId){
		return bookingService.getByGuestid(guestId);
	}
	
	@GetMapping("/room/{roomnumber}")
	public List<Booking> getByRoom(@PathVariable int roomnumber){
		return bookingService.getByRoom(roomnumber);
	}

}
