package com.booking.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.booking.entities.Guest;

public interface GuestRepository extends JpaRepository<Guest, Long>{

}
