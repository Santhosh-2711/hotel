package com.booking.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.booking.entities.Booking;
import java.time.LocalDate;


public interface BookingRepository extends JpaRepository<Booking, Long> {
	
	List<Booking> findByCheckindate(LocalDate checkindate);
	
	List<Booking> findByCheckoutdate(LocalDate checkoutdate);
	
	List<Booking> findByNoofnights(Integer noofnights);
	
	List<Booking> findByGuest_GuestId(Long guestId);
	
	List<Booking> findByRoomnumber(int roomnumber);

}
