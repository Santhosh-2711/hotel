package com.booking.entities;



public class RoomManagement {
	
	private int roomnumber;
	
	private String roomoccupancy;
	
	public RoomManagement() {
		
	}
	
	public RoomManagement(int roomnumber, String roomoccupancy) {
		super();
		this.roomnumber = roomnumber;
		this.roomoccupancy = roomoccupancy;
	}
	
	
	public int getRoomnumber() {
		return roomnumber;
	}
	public void setRoomnumber(int roomnumber) {
		this.roomnumber = roomnumber;
	}
	public String getRoomoccupancy() {
		return roomoccupancy;
	}
	public void setRoomoccupancy(String roomoccupancy) {
		this.roomoccupancy = roomoccupancy;
	}
	
	
	
	
	

	
	
}
