package com.booking.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class Guest {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long guestId;
	
	private Long guestPhoneNo;
	private String company;
	private String name;
	private String email;
	private String gender;
	private String address;
	
	
	public Guest() {
		
	}


	public Guest(Long guestId, Long guestPhoneNo, String company, String name, String email, String gender,
			String address) {
		super();
		this.guestId = guestId;
		this.guestPhoneNo = guestPhoneNo;
		this.company = company;
		this.name = name;
		this.email = email;
		this.gender = gender;
		this.address = address;
	}


	public Long getGuestId() {
		return guestId;
	}


	public void setGuestId(Long guestId) {
		this.guestId = guestId;
	}


	public Long getGuestPhoneNo() {
		return guestPhoneNo;
	}


	public void setGuestPhoneNo(Long guestPhoneNo) {
		this.guestPhoneNo = guestPhoneNo;
	}


	public String getCompany() {
		return company;
	}


	public void setCompany(String company) {
		this.company = company;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public String getGender() {
		return gender;
	}


	public void setGender(String gender) {
		this.gender = gender;
	}


	public String getAddress() {
		return address;
	}


	public void setAddress(String address) {
		this.address = address;
	}
	
	
	
	

}
