package com.booking.entities;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

import jakarta.validation.constraints.NotNull;


import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;


@Entity
public class Booking {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long bookId;
	
	private int noofAdults;
	private int noofChildren;
	@NotNull(message = "check-in date cannot be null")
	private LocalDate checkindate;
	@NotNull(message = "check-out date cannot be null")
	private LocalDate checkoutdate;
	private String status;
	private Integer noofnights;
	private int roomnumber;
	private Long guestId;
	
	@ManyToOne
	@JoinColumn(name="guestId", referencedColumnName = "guestId",insertable = false, updatable = false)
	private Guest guest;
	
	
	
	


	public Long getBookId() {
		return bookId;
	}



	public void setBookId(Long bookId) {
		this.bookId = bookId;
	}



	public int getNoofAdults() {
		return noofAdults;
	}



	public void setNoofAdults(int noofAdults) {
		this.noofAdults = noofAdults;
	}



	public int getNoofChildren() {
		return noofChildren;
	}



	public void setNoofChildren(int noofChildren) {
		this.noofChildren = noofChildren;
	}



	public LocalDate getCheckindate() {
		return checkindate;
	}



	public void setCheckindate(LocalDate checkindate) {
		this.checkindate = checkindate;
		setNoofnights();
	}



	public LocalDate getCheckoutdate() {
		return checkoutdate;
	}



	public void setCheckoutdate(LocalDate checkoutdate) {
		this.checkoutdate = checkoutdate;
		setNoofnights();
	}



	public String getStatus() {
		return status;
	}



	public void setStatus(String status) {
		this.status = status;
	}



	public Integer getNoofnights() {
		return noofnights;
	}



	public void setNoofnights() {
		if (checkindate != null && checkoutdate != null) {
            this.noofnights = (int) ChronoUnit.DAYS.between(checkindate, checkoutdate);
        } else {
            this.noofnights = 0;
        }	}



	public int getRoomnumber() {
		return roomnumber;
	}



	public void setRoomnumber(int roomnumber) {
		this.roomnumber = roomnumber;
	}



	public Long getGuestId() {
		return guestId;
	}



	public void setGuestId(Long guestId) {
		this.guestId = guestId;
	}
	
	
public Booking() {
		
	}

	

	public Booking(Long bookId, int noofAdults, int noofChildren, LocalDate checkindate, LocalDate checkoutdate,
			String status, Integer noofnights,int roomnumber, Long guestId) {
		super();
		this.bookId = bookId;
		this.noofAdults = noofAdults;
		this.noofChildren = noofChildren;
		this.checkindate = checkindate;
		this.checkoutdate = checkoutdate;
		this.status = status;
		this.noofnights = noofnights;
		this.roomnumber = roomnumber;
		this.guestId = guestId;
	}

	
	
}
