package com.booking.controllers;

import com.booking.entities.Guest;
import com.booking.services.GuestService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.Arrays;
import java.util.List;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

class GuestControllerTest {

    @Mock
    private GuestService guestService;

    @InjectMocks
    private GuestController guestController;

    private Guest guest1;
    private Guest guest2;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);

        guest1 = new Guest(1L, 9848223336L, "CapGemini", "Jaffa", "jaffa@email.com", "Male", "LPU,Jalandhar,Punjab");
        guest2 = new Guest(2L, 9545063322L, "CapGemini", "Kilo", "kilo@email.com", "Female", "CG,Hyderabad,Punjab");
    }

    @Test
    void createGuestTest() {
        when(guestService.add(guest1)).thenReturn(guest1);

        Guest savedGuest = guestController.create(guest1);

        assertNotNull(savedGuest);
        assertEquals(1L, savedGuest.getGuestId());
        assertEquals("Jaffa", savedGuest.getName());
        assertEquals("CapGemini", savedGuest.getCompany());
        assertEquals("jaffa@email.com", savedGuest.getEmail());
        verify(guestService, times(1)).add(guest1);
    }

    @Test
    void getAllGuestsTest() {
        List<Guest> guests = Arrays.asList(
                new Guest(1L, 9848223336L, "CapGemini", "Jaffa", "jaffa@email.com", "Male", "LPU,Jalandhar,Punjab"),
                new Guest(2L, 9545063322L, "CapGemini", "Kilo", "kilo@email.com", "Female", "CG,Hyderabad,Punjab")
        );

        when(guestService.get()).thenReturn(guests);

        List<Guest> result = guestController.getAll();

        assertNotNull(result);
        assertEquals(2, result.size());
        assertEquals("Jaffa", result.get(0).getName());
        assertEquals("Kilo", result.get(1).getName());
        verify(guestService, times(1)).get();
    }

    @Test
    void getGuestByIdTest() {
        when(guestService.getOne(1L)).thenReturn(guest1);

        Guest fetchedGuest = guestController.getAll(1L);

        assertNotNull(fetchedGuest);
        assertEquals(1L, fetchedGuest.getGuestId());
        assertEquals("Jaffa", fetchedGuest.getName());
        verify(guestService, times(1)).getOne(1L);
    }

    @Test
    void updateGuestTest() {
        Guest existingGuest = new Guest(1L, 9848223336L, "CapGemini", "Jaffa", "jaffa@email.com", "Male", "LPU,Jalandhar,Punjab");
        
        Guest updatedGuest = new Guest(1L, 9848223336L, "CapGemini", "Jaffa Updated", "jaffa.updated@email.com", "Male", "LPU,Jalandhar,Punjab");

        when(guestService.getOne(1L)).thenReturn(existingGuest);

        when(guestService.add(any(Guest.class))).thenAnswer(invocation -> {
            Guest guestToUpdate = invocation.getArgument(0);
            guestToUpdate.setGuestPhoneNo(9848223336L);
            guestToUpdate.setCompany("CapGemini");
            return guestToUpdate;
        });

        Guest result = guestController.updateGuest(1L, updatedGuest);

        assertNotNull(result);
        assertEquals("Jaffa Updated", result.getName());
        assertEquals("jaffa.updated@email.com", result.getEmail());
        assertEquals("CapGemini", result.getCompany());
        assertEquals(9848223336L, result.getGuestPhoneNo());
        assertEquals("Male", result.getGender());
        assertEquals("LPU,Jalandhar,Punjab", result.getAddress());

        verify(guestService, times(1)).getOne(1L);
        verify(guestService, times(1)).add(any(Guest.class));
    }

    @Test
    void deleteGuestTest() {
        when(guestService.getOne(1L)).thenReturn(guest1);

        String result = guestController.removeGuest(1L);

        assertEquals("Guest deleted Successfully", result);
        verify(guestService, times(1)).getOne(1L);
        verify(guestService, times(1)).delete(guest1);
    }
}
