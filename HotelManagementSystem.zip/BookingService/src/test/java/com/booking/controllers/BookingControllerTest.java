package com.booking.controllers;

import com.booking.entities.Booking;
import com.booking.services.BookingService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

class BookingControllerTest {

    @Mock
    private BookingService bookingService;

    @InjectMocks
    private BookingController bookingController;

    private Booking booking;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);

        booking = new Booking();
        booking.setBookId(1L);
        booking.setNoofAdults(2);
        booking.setNoofChildren(2);
        booking.setCheckindate(LocalDate.of(2025, 3, 26));
        booking.setCheckoutdate(LocalDate.of(2025, 3, 28));
        booking.setStatus("Completed");
        booking.setNoofnights();
        booking.setRoomnumber(105);
        booking.setGuestId(1L);
    }

    @Test
    void createBookingTest() {
        when(bookingService.add(booking)).thenReturn(booking);

        Booking savedBooking = bookingController.create(booking);

        assertNotNull(savedBooking);
        assertEquals(1L, savedBooking.getBookId());
        assertEquals("Completed", savedBooking.getStatus());
        assertEquals(105, savedBooking.getRoomnumber());
        verify(bookingService, times(1)).add(booking);
    }

    @Test
    void getAllBookingsTest() {
        List<Booking> bookings = Arrays.asList(
                new Booking(1L, 2, 2, LocalDate.of(2025, 3, 26), LocalDate.of(2025, 3, 28), "Completed", 2, 105, 1L),
                new Booking(2L, 1, 1, LocalDate.of(2025, 3, 27), LocalDate.of(2025, 3, 29), "Pending", 2, 106, 2L)
        );
        when(bookingService.get()).thenReturn(bookings);

        List<Booking> result = bookingController.getAll();

        assertNotNull(result);
        assertEquals(2, result.size());
        assertEquals("Completed", result.get(0).getStatus());
        verify(bookingService, times(1)).get();
    }

    @Test
    void getBookingByIdTest() {
        when(bookingService.getOne(1L)).thenReturn(booking);

        Booking fetchedBooking = bookingController.getAll(1L);

        assertNotNull(fetchedBooking);
        assertEquals(1L, fetchedBooking.getBookId());
        assertEquals("Completed", fetchedBooking.getStatus());
        verify(bookingService, times(1)).getOne(1L);
    }

    @Test
    void updateBookingTest() {
        Booking existingBooking = new Booking(1L, 2, 2, LocalDate.of(2025, 3, 26), LocalDate.of(2025, 3, 28), "Completed", 2, 105, 1L);
        Booking updatedBooking = new Booking(1L, 3, 3, LocalDate.of(2025, 3, 27), LocalDate.of(2025, 3, 29), "Pending", 2, 105, 1L);

        when(bookingService.getOne(1L)).thenReturn(existingBooking);
        when(bookingService.add(any(Booking.class))).thenReturn(updatedBooking);

        Booking result = bookingController.updateBooking(1L, updatedBooking);

        assertNotNull(result);
        assertEquals("Pending", result.getStatus());
        assertEquals(105, result.getRoomnumber());
        assertEquals(3, result.getNoofAdults());
        assertEquals(3, result.getNoofChildren());
        assertEquals(LocalDate.of(2025, 3, 27), result.getCheckindate());
        assertEquals(LocalDate.of(2025, 3, 29), result.getCheckoutdate());

        verify(bookingService, times(1)).getOne(1L);
        verify(bookingService, times(1)).add(any(Booking.class));
    }

    @Test
    void deleteBookingTest() {
        when(bookingService.getOne(1L)).thenReturn(booking);

        String result = bookingController.removebooking(1L);

        assertEquals("Booking deleted Successfully", result);
        verify(bookingService, times(1)).getOne(1L);
        verify(bookingService, times(1)).delete(booking);
    }
}
