package com.booking.services.impl;

import com.booking.entities.Guest;
import com.booking.repositories.GuestRepository;
import com.booking.services.GuestService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Arrays;
import java.util.List;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

class GuestServiceImplTest {

    @Mock
    private GuestRepository guestRepository;

    @InjectMocks
    private GuestServiceImpl guestService;

    private Guest guest1;
    private Guest guest2;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);

        guest1 = new Guest(1L, 9848223336L, "CapGemini", "Jaffa", "jaffa@email.com", "Male", "LPU,Jalandhar,Punjab");
        guest2 = new Guest(2L, 9545063322L, "CapGemini", "Kilo", "kilo@email.com", "Female", "CG,Hyderabad,Punjab");
    }

    @Test
    void addGuestTest() {
        when(guestRepository.save(guest1)).thenReturn(guest1);

        Guest savedGuest = guestService.add(guest1);

        assertNotNull(savedGuest);
        assertEquals(1L, savedGuest.getGuestId());
        assertEquals("Jaffa", savedGuest.getName());
        assertEquals("CapGemini", savedGuest.getCompany());
        assertEquals("jaffa@email.com", savedGuest.getEmail());
        verify(guestRepository, times(1)).save(guest1);
    }

    @Test
    void getAllGuestsTest() {
        List<Guest> guests = Arrays.asList(
                new Guest(1L, 9848223336L, "CapGemini", "Jaffa", "jaffa@email.com", "Male", "LPU,Jalandhar,Punjab"),
                new Guest(2L, 9545063322L, "CapGemini", "Kilo", "kilo@email.com", "Female", "CG,Hyderabad,Punjab")
        );

        when(guestRepository.findAll()).thenReturn(guests);

        List<Guest> result = guestService.get();

        assertNotNull(result);
        assertEquals(2, result.size());
        assertEquals("Jaffa", result.get(0).getName());
        assertEquals("Kilo", result.get(1).getName());
        verify(guestRepository, times(1)).findAll();
    }

    @Test
    void getGuestByIdTest() {
        when(guestRepository.findById(1L)).thenReturn(java.util.Optional.of(guest1));

        Guest fetchedGuest = guestService.getOne(1L);

        assertNotNull(fetchedGuest);
        assertEquals(1L, fetchedGuest.getGuestId());
        assertEquals("Jaffa", fetchedGuest.getName());
        verify(guestRepository, times(1)).findById(1L);
    }

    @Test
    void updateGuestTest() {
        Guest updatedGuest = new Guest(1L, 9848223336L, "CapGemini", "Jaffa Updated", "jaffa.updated@email.com", "Male", "LPU,Jalandhar,Punjab");

        when(guestRepository.findById(1L)).thenReturn(java.util.Optional.of(guest1));
        when(guestRepository.save(updatedGuest)).thenReturn(updatedGuest);

        Guest result = guestService.add(updatedGuest);

        assertNotNull(result);
        assertEquals("Jaffa Updated", result.getName());
        assertEquals("jaffa.updated@email.com", result.getEmail());
        verify(guestRepository, times(1)).save(updatedGuest);
    }

    @Test
    void deleteGuestTest() {
        when(guestRepository.findById(1L)).thenReturn(java.util.Optional.of(guest1));

        guestService.delete(guest1);

        verify(guestRepository, times(1)).delete(guest1);
    }
}
