package com.booking.services.impl;

import com.booking.client.RoomClient;
import com.booking.entities.Booking;
import com.booking.entities.RoomManagement;
import com.booking.repositories.BookingRepository;
import com.booking.services.BookingService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

class BookingServiceImplTest {

    @Mock
    private BookingRepository bookingRepository;

    @InjectMocks
    private BookingServiceImpl bookingService;

    private Booking booking;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);

        booking = new Booking();
        booking.setBookId(1L);
        booking.setNoofAdults(2);
        booking.setNoofChildren(2);
        booking.setCheckindate(LocalDate.of(2025, 3, 26));
        booking.setCheckoutdate(LocalDate.of(2025, 3, 28));
        booking.setStatus("Completed");
        booking.setNoofnights();
        booking.setRoomnumber(105);
        booking.setGuestId(1L);
    }

    @Test
    void addBookingTest() {
        Booking booking = new Booking();
        booking.setNoofAdults(2);
        booking.setNoofChildren(2);
        booking.setCheckindate(LocalDate.of(2025, 3, 26));
        booking.setCheckoutdate(LocalDate.of(2025, 3, 28));
        booking.setStatus("Completed");
        booking.setRoomnumber(105);
        booking.setGuestId(1L);

        RoomManagement roomManagement = new RoomManagement();
        roomManagement.setRoomoccupancy("Occupied");

        RoomClient roomClient = mock(RoomClient.class);
        when(roomClient.updateRoomOccupancy(anyInt(), any(RoomManagement.class))).thenReturn(roomManagement);

        BookingRepository bookingRepository = mock(BookingRepository.class);
        when(bookingRepository.save(any(Booking.class))).thenReturn(booking);

        BookingService bookingService = new BookingServiceImpl(bookingRepository, roomClient);

        Booking savedBooking = bookingService.add(booking);

        assertNotNull(savedBooking);
        assertEquals("Completed", savedBooking.getStatus());
        assertEquals(105, savedBooking.getRoomnumber());
        assertEquals(2, savedBooking.getNoofAdults());
        assertEquals(2, savedBooking.getNoofChildren());
        assertEquals(LocalDate.of(2025, 3, 26), savedBooking.getCheckindate());
        assertEquals(LocalDate.of(2025, 3, 28), savedBooking.getCheckoutdate());

        verify(bookingRepository, times(1)).save(any(Booking.class));
        verify(roomClient, times(1)).updateRoomOccupancy(anyInt(), any(RoomManagement.class));
    }



    @Test
    void getAllBookingsTest() {
        List<Booking> bookings = Arrays.asList(
                new Booking(1L, 2, 2, LocalDate.of(2025, 3, 26), LocalDate.of(2025, 3, 28), "Completed", 2, 105, 1L),
                new Booking(2L, 1, 1, LocalDate.of(2025, 3, 27), LocalDate.of(2025, 3, 29), "Pending", 2, 106, 2L)
        );
        when(bookingRepository.findAll()).thenReturn(bookings);

        List<Booking> result = bookingService.get();

        assertNotNull(result);
        assertEquals(2, result.size());
        assertEquals("Completed", result.get(0).getStatus());
        verify(bookingRepository, times(1)).findAll();
    }

    @Test
    void getBookingByIdTest() {
        when(bookingRepository.findById(1L)).thenReturn(java.util.Optional.of(booking));

        Booking fetchedBooking = bookingService.getOne(1L);

        assertNotNull(fetchedBooking);
        assertEquals(1L, fetchedBooking.getBookId());
        assertEquals("Completed", fetchedBooking.getStatus());
        verify(bookingRepository, times(1)).findById(1L);
    }

    @Test
    void deleteBookingTest() {
        when(bookingRepository.findById(1L)).thenReturn(java.util.Optional.of(booking));

        bookingService.delete(booking);

        verify(bookingRepository, times(1)).delete(booking);
    }
}
