package com.sms.service.impl;

import com.sms.entities.StaffManagement;
import com.sms.repositories.SmsRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

class SmsServiceImplTest {

    @Mock
    private SmsRepository smsRepository;

    @InjectMocks
    private SmsServiceImpl smsService;

    private StaffManagement staff;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        staff = new StaffManagement(10002345L, "Raju", "Lpu,Jalandhar,Punjab", 5212721252L, 50000, 26, "Receptionist", "raju@email.com");
    }

    @Test
    void addStaffTest() {
        when(smsRepository.save(staff)).thenReturn(staff);

        StaffManagement result = smsService.add(staff);

        assertNotNull(result);
        assertEquals(10002345L, result.getStaff_code());
        assertEquals("Raju", result.getEmployee_name());
        assertEquals("Lpu,Jalandhar,Punjab", result.getEmployee_address());
        assertEquals(5212721252L, result.getEmployee_nic());
        assertEquals(50000, result.getEmployee_salary());
        assertEquals(26, result.getEmployee_age());
        assertEquals("Receptionist", result.getEmployee_occupation());
        assertEquals("raju@email.com", result.getEmployee_email());
        verify(smsRepository, times(1)).save(staff);
    }

    @Test
    void getAllStaffTest() {
        List<StaffManagement> staffList = Arrays.asList(
                new StaffManagement(10002345L, "Raju", "Lpu,Jalandhar,Punjab", 5212721252L, 50000, 26, "Receptionist", "raju@email.com"),
                new StaffManagement(10002346L, "Anil", "Lpu,Jalandhar,Punjab", 5212721253L, 55000, 28, "Manager", "anil@email.com")
        );
        when(smsRepository.findAll()).thenReturn(staffList);

        List<StaffManagement> result = smsService.get();

        assertNotNull(result);
        assertEquals(2, result.size());
        verify(smsRepository, times(1)).findAll();
    }

    @Test
    void getStaffByIdTest() {
        when(smsRepository.findById(10002345L)).thenReturn(Optional.of(staff));

        StaffManagement result = smsService.getOne(10002345L);

        assertNotNull(result);
        assertEquals(10002345L, result.getStaff_code());
        assertEquals("Raju", result.getEmployee_name());
        assertEquals("Lpu,Jalandhar,Punjab", result.getEmployee_address());
        assertEquals(5212721252L, result.getEmployee_nic());
        assertEquals(50000, result.getEmployee_salary());
        assertEquals(26, result.getEmployee_age());
        assertEquals("Receptionist", result.getEmployee_occupation());
        assertEquals("raju@email.com", result.getEmployee_email());
        verify(smsRepository, times(1)).findById(10002345L);
    }

    @Test
    void deleteStaffTest() {
        when(smsRepository.findById(10002345L)).thenReturn(Optional.of(staff));

        smsService.delete(staff);

        verify(smsRepository, times(1)).delete(staff);
    }
}
