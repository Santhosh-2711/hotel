package com.sms.controllers;

import com.sms.entities.StaffManagement;
import com.sms.service.SmsService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Arrays;
import java.util.List;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

class SmsControllerTest {

    @Mock
    private SmsService smsService;

    @InjectMocks
    private SmsController smsController;

    private StaffManagement staff;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        staff = new StaffManagement(10002345L, "Raju", "Lpu,Jalandhar,Punjab", 5212721252L, 50000, 26, "Receptionist", "raju@email.com");
    }

    @Test
    void createStaffTest() {
        when(smsService.add(staff)).thenReturn(staff);

        StaffManagement createdStaff = smsController.create(staff);

        assertNotNull(createdStaff);
        assertEquals(10002345L, createdStaff.getStaff_code());
        assertEquals("Raju", createdStaff.getEmployee_name());
        assertEquals("Lpu,Jalandhar,Punjab", createdStaff.getEmployee_address());
        assertEquals(5212721252L, createdStaff.getEmployee_nic());
        assertEquals(50000, createdStaff.getEmployee_salary());
        assertEquals(26, createdStaff.getEmployee_age());
        assertEquals("Receptionist", createdStaff.getEmployee_occupation());
        assertEquals("raju@email.com", createdStaff.getEmployee_email());
        verify(smsService, times(1)).add(staff);
    }

    @Test
    void getAllStaffTest() {
        List<StaffManagement> staffList = Arrays.asList(
                new StaffManagement(10002345L, "Raju", "Lpu,Jalandhar,Punjab", 5212721252L, 50000, 26, "Receptionist", "raju@email.com"),
                new StaffManagement(10002346L, "Anil", "Lpu,Jalandhar,Punjab", 5212721253L, 55000, 28, "Manager", "anil@email.com")
        );
        when(smsService.get()).thenReturn(staffList);

        List<StaffManagement> result = smsController.getAll();

        assertNotNull(result);
        assertEquals(2, result.size());
        verify(smsService, times(1)).get();
    }

    @Test
    void getStaffByIdTest() {
        when(smsService.getOne(10002345L)).thenReturn(staff);

        StaffManagement fetchedStaff = smsController.getAll(10002345L);

        assertNotNull(fetchedStaff);
        assertEquals(10002345L, fetchedStaff.getStaff_code());
        assertEquals("Raju", fetchedStaff.getEmployee_name());
        assertEquals("Lpu,Jalandhar,Punjab", fetchedStaff.getEmployee_address());
        assertEquals(5212721252L, fetchedStaff.getEmployee_nic());
        assertEquals(50000, fetchedStaff.getEmployee_salary());
        assertEquals(26, fetchedStaff.getEmployee_age());
        assertEquals("Receptionist", fetchedStaff.getEmployee_occupation());
        assertEquals("raju@email.com", fetchedStaff.getEmployee_email());
        verify(smsService, times(1)).getOne(10002345L);
    }

    @Test
    void updateStaffTest() {
        StaffManagement existingStaff = new StaffManagement(10002345L, "Raju", "Lpu,Jalandhar,Punjab", 5212721252L, 50000, 26, "Receptionist", "raju@email.com");
        StaffManagement updatedStaff = new StaffManagement(10002345L, "Raju Updated", "Lpu,Jalandhar, Punjab Updated", 5212721252L, 55000, 27, "Receptionist Updated", "raju.updated@email.com");
        
        when(smsService.getOne(10002345L)).thenReturn(existingStaff);
        when(smsService.add(any(StaffManagement.class))).thenReturn(updatedStaff);

        StaffManagement result = smsController.updateStaff(10002345L, updatedStaff);

        assertNotNull(result);
        assertEquals(10002345L, result.getStaff_code());
        assertEquals("Raju Updated", result.getEmployee_name());
        assertEquals("Lpu,Jalandhar, Punjab Updated", result.getEmployee_address());
        assertEquals(5212721252L, result.getEmployee_nic());
        assertEquals(55000, result.getEmployee_salary());
        assertEquals(27, result.getEmployee_age());
        assertEquals("Receptionist Updated", result.getEmployee_occupation());
        assertEquals("raju.updated@email.com", result.getEmployee_email());

        verify(smsService, times(1)).getOne(10002345L);
        verify(smsService, times(1)).add(any(StaffManagement.class));
    }

    
    @Test
    void deleteStaffTest() {
        when(smsService.getOne(10002345L)).thenReturn(staff);

        String result = smsController.removeStaff(10002345L);

        assertEquals("Room deleted Successfully", result);
        verify(smsService, times(1)).getOne(10002345L);
        verify(smsService, times(1)).delete(staff);
    }
}
