package com.sms.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class StaffManagement {
	
	@Id
	private Long staff_code;
	
	private String employee_name;
	private String employee_address;
	private Long employee_nic;
	private int employee_salary;
	private int employee_age;
	private String employee_occupation;
	private String employee_email;
	
	public StaffManagement() {
		
	}
	
	public StaffManagement(Long staff_code, String employee_name, String employee_address, Long employee_nic,
			int employee_salary, int employee_age, String employee_occupation, String employee_email) {
		super();
		this.staff_code = staff_code;
		this.employee_name = employee_name;
		this.employee_address = employee_address;
		this.employee_nic = employee_nic;
		this.employee_salary = employee_salary;
		this.employee_age = employee_age;
		this.employee_occupation = employee_occupation;
		this.employee_email = employee_email;
	}

	public Long getStaff_code() {
		return staff_code;
	}

	public void setStaff_code(Long staff_code) {
		this.staff_code = staff_code;
	}

	public String getEmployee_name() {
		return employee_name;
	}

	public void setEmployee_name(String employee_name) {
		this.employee_name = employee_name;
	}

	public String getEmployee_address() {
		return employee_address;
	}

	public void setEmployee_address(String employee_address) {
		this.employee_address = employee_address;
	}

	public Long getEmployee_nic() {
		return employee_nic;
	}

	public void setEmployee_nic(Long employee_nic) {
		this.employee_nic = employee_nic;
	}

	public int getEmployee_salary() {
		return employee_salary;
	}

	public void setEmployee_salary(int employee_salary) {
		this.employee_salary = employee_salary;
	}

	public int getEmployee_age() {
		return employee_age;
	}

	public void setEmployee_age(int employee_age) {
		this.employee_age = employee_age;
	}

	public String getEmployee_occupation() {
		return employee_occupation;
	}

	public void setEmployee_occupation(String employee_occupation) {
		this.employee_occupation = employee_occupation;
	}

	public String getEmployee_email() {
		return employee_email;
	}

	public void setEmployee_email(String employee_email) {
		this.employee_email = employee_email;
	}
	
	
	

}
