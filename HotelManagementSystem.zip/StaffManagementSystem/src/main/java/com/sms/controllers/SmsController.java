package com.sms.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sms.entities.StaffManagement;
import com.sms.service.SmsService;

@RestController
@RequestMapping("/sms")
public class SmsController {
	
	@Autowired
	private SmsService smsService;
	
	
	@PostMapping
	public StaffManagement create(@RequestBody StaffManagement staffManagement) {
		return smsService.add(staffManagement);
	}
	
	@GetMapping
	public List<StaffManagement> getAll(){
		return smsService.get();
	}
	
	@GetMapping("/{id}")
	public StaffManagement getAll(@PathVariable Long id){
		return smsService.getOne(id);
	}
	
	@PutMapping("/{id}")
	public StaffManagement updateStaff(@PathVariable Long id,@RequestBody StaffManagement staffManagement) {
		StaffManagement change =  smsService.getOne(id);
		
		change.setStaff_code(staffManagement.getStaff_code());
		change.setEmployee_name(staffManagement.getEmployee_name());
		change.setEmployee_address(staffManagement.getEmployee_address());
		change.setEmployee_nic(staffManagement.getEmployee_nic());
		change.setEmployee_salary(staffManagement.getEmployee_salary());
		change.setEmployee_age(staffManagement.getEmployee_age());
		change.setEmployee_occupation(staffManagement.getEmployee_occupation());
		change.setEmployee_email(staffManagement.getEmployee_email());
		return smsService.add(change);
		
	}
	
	@DeleteMapping("delete/{id}")
	public String removeStaff(@PathVariable Long id) {
		StaffManagement room = smsService.getOne(id);
	    smsService.delete(room);
	    return "Room deleted Successfully";
	}

}
