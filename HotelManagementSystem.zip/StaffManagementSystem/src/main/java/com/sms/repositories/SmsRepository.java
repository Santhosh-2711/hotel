package com.sms.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sms.entities.StaffManagement;

public interface SmsRepository extends JpaRepository<StaffManagement, Long>{

}
