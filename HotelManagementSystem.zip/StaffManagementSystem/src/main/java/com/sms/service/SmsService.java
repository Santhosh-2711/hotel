package com.sms.service;

import java.util.List;

import com.sms.entities.StaffManagement;

public interface SmsService {
	
	StaffManagement add(StaffManagement staffManagement);
	List<StaffManagement> get();
	StaffManagement getOne(Long id);
	void delete(StaffManagement staff);

}
