package com.sms.service.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.sms.entities.StaffManagement;
import com.sms.repositories.SmsRepository;
import com.sms.service.SmsService;

@Service
public class SmsServiceImpl implements SmsService {
	
	private static Logger logger = LoggerFactory.getLogger(SmsServiceImpl.class);
	
	private SmsRepository smsRepository;

	public SmsServiceImpl(SmsRepository smsRepository) {
		super();
		this.smsRepository = smsRepository;
	}

	@Override
	public StaffManagement add(StaffManagement staffManagement) {
		logger.info("Request received to add StaffManagement: {}", staffManagement);
		try {
			StaffManagement savedStaff = smsRepository.save(staffManagement);
			logger.info("StaffManagement added successfully: {}", savedStaff);
			return savedStaff;
		} catch (Exception e) {
			logger.error("Error occurred while adding StaffManagement: {}", e.getMessage(), e);
			return null;
		}
	}

	@Override
	public List<StaffManagement> get() {
		logger.info("Fetching all StaffManagement entries");
		try {
			List<StaffManagement> staffList = smsRepository.findAll();
			logger.info("Fetched {} StaffManagement entries", staffList.size());
			return staffList;
		} catch (Exception e) {
			logger.error("Error occurred while fetching StaffManagement entries: {}", e.getMessage(), e);
			return null;
		}
	}

	@Override
	public StaffManagement getOne(Long id) {
		logger.info("Fetching StaffManagement entry with id: {}", id);
		try {
			StaffManagement staff = smsRepository.findById(id).orElseThrow();
			logger.info("Fetched StaffManagement entry: {}", staff);
			return staff;
		} catch (Exception e) {
			logger.error("Error occurred while fetching StaffManagement with id {}: {}", id, e.getMessage(), e);
			return null;
		}
	}

	@Override
	public void delete(StaffManagement staff) {
		logger.info("Request received to delete StaffManagement: {}", staff);
		try {
			smsRepository.delete(staff);
			logger.info("StaffManagement deleted successfully: {}", staff);
		} catch (Exception e) {
			logger.error("Error occurred while deleting StaffManagement: {}", e.getMessage(), e);
		}
	}
}
