package com.rms.services;

import java.util.List;

import com.rms.entities.RoomManagement;

public interface RmsService {
	
	RoomManagement add(RoomManagement roomMangement);
	
	List<RoomManagement> get();
	
	RoomManagement get(Integer id);

	void delete(RoomManagement room);

}
