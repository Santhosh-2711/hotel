package com.rms.services.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.rms.entities.RoomManagement;
import com.rms.repositories.RmsRepository;
import com.rms.services.RmsService;

@Service
public class RmsServiceImpl implements RmsService {

    private static Logger logger = LoggerFactory.getLogger(RmsServiceImpl.class);

    private RmsRepository rmsRepository;

    public RmsServiceImpl(RmsRepository rmsRepository) {
        this.rmsRepository = rmsRepository;
    }

    @Override
    public RoomManagement add(RoomManagement roomManagement) {
        logger.info("Request received to add RoomManagement: {}", roomManagement);
        try {
            RoomManagement savedRoom = rmsRepository.save(roomManagement);
            logger.info("RoomManagement saved successfully: {}", savedRoom);
            return savedRoom;
        } catch (Exception e) {
            logger.error("Error occurred while adding RoomManagement: {}", e.getMessage(), e);
            throw new RuntimeException("Failed to add RoomManagement", e);
        }
    }

    @Override
    public List<RoomManagement> get() {
        logger.info("Fetching all RoomManagement entries");
        try {
            List<RoomManagement> rooms = rmsRepository.findAll();
            logger.info("Fetched {} RoomManagement entries", rooms.size());
            return rooms;
        } catch (Exception e) {
            logger.error("Error occurred while fetching RoomManagement entries: {}", e.getMessage(), e);
            throw new RuntimeException("Failed to fetch RoomManagement entries", e);
        }
    }

    @Override
    public RoomManagement get(Integer id) {
        logger.info("Fetching RoomManagement entry with id: {}", id);
        try {
            RoomManagement room = rmsRepository.findById(id).orElseThrow();
            logger.info("Fetched RoomManagement entry: {}", room);
            return room;
        } catch (Exception e) {
            logger.error("Error occurred while fetching RoomManagement with id {}: {}", id, e.getMessage(), e);
            throw new RuntimeException("Room not found", e);
        }
    }

    @Override
    public void delete(RoomManagement room) {
        logger.info("Request received to delete RoomManagement: {}", room);
        try {
            rmsRepository.delete(room);
            logger.info("RoomManagement deleted successfully: {}", room);
        } catch (Exception e) {
            logger.error("Error occurred while deleting RoomManagement: {}", e.getMessage(), e);
            throw new RuntimeException("Failed to delete RoomManagement", e);
        }
    }
}
