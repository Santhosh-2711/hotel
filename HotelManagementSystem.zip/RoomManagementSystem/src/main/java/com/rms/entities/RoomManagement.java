package com.rms.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class RoomManagement {
	
	@Id
	private int roomnumber;
	
	private String roomtype;
	private int roomsize;
	private String roomoccupancy;
	
	public RoomManagement() {
		
	}
	
	public RoomManagement(int roomnumber, String roomtype, int roomsize, String roomoccupancy) {
		super();
		this.roomnumber = roomnumber;
		this.roomtype = roomtype;
		this.roomsize = roomsize;
		this.roomoccupancy = roomoccupancy;
	}
	
	
	public int getRoomnumber() {
		return roomnumber;
	}
	public void setRoomnumber(int roomnumber) {
		this.roomnumber = roomnumber;
	}
	public String getRoomtype() {
		return roomtype;
	}
	public void setRoomtype(String roomtype) {
		this.roomtype = roomtype;
	}
	public int getRoomsize() {
		return roomsize;
	}
	public void setRoomsize(int roomsize) {
		this.roomsize = roomsize;
	}
	public String getRoomoccupancy() {
		return roomoccupancy;
	}
	public void setRoomoccupancy(String roomoccupancy) {
		this.roomoccupancy = roomoccupancy;
	}
	
	
	
	
	

	
	
}
