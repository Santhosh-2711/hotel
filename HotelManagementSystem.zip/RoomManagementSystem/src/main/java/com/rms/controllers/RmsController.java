package com.rms.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.rms.entities.RoomManagement;
import com.rms.services.RmsService;

@RestController
@RequestMapping("/rms")
public class RmsController {
	
	@Autowired
	private RmsService rmsService;
	
	
	@PostMapping
	public RoomManagement create(@RequestBody RoomManagement roomMangement) {
		return rmsService.add(roomMangement);
	}
	
	@GetMapping
	public List<RoomManagement> get(){
		return rmsService.get();
	}
	
	@GetMapping("/{id}")
	public RoomManagement getOne(@PathVariable Integer id){
		return rmsService.get(id);
	}
	
	@PutMapping("/{id}")
	public RoomManagement updateRooms(@PathVariable Integer id,@RequestBody RoomManagement roomMangement) {
		RoomManagement change =  rmsService.get(id);
		
		change.setRoomoccupancy(roomMangement.getRoomoccupancy());
		return rmsService.add(change);
		
	}
	
	@DeleteMapping("delete/{id}")
	public String removeRoom(@PathVariable Integer id) {
		RoomManagement room = rmsService.get(id);
	    rmsService.delete(room);
	    return "Room deleted Successfully";
	}
	

}
