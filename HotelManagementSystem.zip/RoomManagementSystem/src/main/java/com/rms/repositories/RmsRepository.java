package com.rms.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.rms.entities.RoomManagement;

@Repository
public interface RmsRepository extends JpaRepository<RoomManagement, Integer>{

}
