package com.rms.services.impl;

import com.rms.entities.RoomManagement;
import com.rms.repositories.RmsRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

class RmsServiceImplTest {

    @Mock
    private RmsRepository rmsRepository;

    @InjectMocks
    private RmsServiceImpl rmsService;

    private RoomManagement room;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        room = new RoomManagement(101, "Deluxe", 2, "Vacant");
    }

    @Test
    void addRoomTest() {
        when(rmsRepository.save(room)).thenReturn(room);

        RoomManagement result = rmsService.add(room);

        assertNotNull(result);
        assertEquals(101, result.getRoomnumber());
        assertEquals("Deluxe", result.getRoomtype());
        assertEquals(2, result.getRoomsize());
        assertEquals("Vacant", result.getRoomoccupancy());
        verify(rmsRepository, times(1)).save(room);
    }

    @Test
    void getAllRoomsTest() {
        List<RoomManagement> rooms = Arrays.asList(
                new RoomManagement(101, "Deluxe", 2, "Vacant"),
                new RoomManagement(102, "Normal", 3, "Occupied")
        );
        when(rmsRepository.findAll()).thenReturn(rooms);

        List<RoomManagement> result = rmsService.get();

        assertNotNull(result);
        assertEquals(2, result.size());
        verify(rmsRepository, times(1)).findAll();
    }

    @Test
    void getRoomByIdTest() {
        when(rmsRepository.findById(101)).thenReturn(Optional.of(room));

        RoomManagement result = rmsService.get(101);

        assertNotNull(result);
        assertEquals(101, result.getRoomnumber());
        assertEquals("Deluxe", result.getRoomtype());
        assertEquals(2, result.getRoomsize());
        assertEquals("Vacant", result.getRoomoccupancy());
        verify(rmsRepository, times(1)).findById(101);
    }

    @Test
    void deleteRoomTest() {
        when(rmsRepository.findById(101)).thenReturn(Optional.of(room));

        rmsService.delete(room);

        verify(rmsRepository, times(1)).delete(room);
    }
}
