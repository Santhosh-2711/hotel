package com.rms.controllers;

import com.rms.entities.RoomManagement;
import com.rms.services.RmsService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.ResponseEntity;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

class RmsControllerTest {

    @Mock
    private RmsService rmsService;

    @InjectMocks
    private RmsController rmsController;

    private RoomManagement room;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        room = new RoomManagement(101, "Deluxe", 2, "Vacant");
    }

    @Test
    void createRoomTest() {
        when(rmsService.add(room)).thenReturn(room);

        RoomManagement createdRoom = rmsController.create(room);

        assertNotNull(createdRoom);
        assertEquals(101, createdRoom.getRoomnumber());
        assertEquals("Deluxe", createdRoom.getRoomtype());
        assertEquals(2, createdRoom.getRoomsize());
        assertEquals("Vacant", createdRoom.getRoomoccupancy());
        verify(rmsService, times(1)).add(room);
    }

    @Test
    void getAllRoomsTest() {
        List<RoomManagement> rooms = Arrays.asList(
                new RoomManagement(101, "Deluxe", 2, "Vacant"),
                new RoomManagement(102, "Normal", 3, "Occupied")
        );
        when(rmsService.get()).thenReturn(rooms);

        List<RoomManagement> roomList = rmsController.get();

        assertNotNull(roomList);
        assertEquals(2, roomList.size());
        verify(rmsService, times(1)).get();
    }

    @Test
    void getRoomByIdTest() {
        when(rmsService.get(101)).thenReturn(room);

        RoomManagement fetchedRoom = rmsController.getOne(101);

        assertNotNull(fetchedRoom);
        assertEquals(101, fetchedRoom.getRoomnumber());
        assertEquals("Deluxe", fetchedRoom.getRoomtype());
        assertEquals(2, fetchedRoom.getRoomsize());
        assertEquals("Vacant", fetchedRoom.getRoomoccupancy());
        verify(rmsService, times(1)).get(101);
    }

    @Test
    void updateRoomTest() {
        RoomManagement room = new RoomManagement(101, "Deluxe", 2, "Vacant");
        RoomManagement updatedRoom = new RoomManagement(101, "Deluxe", 2, "Occupied");

        when(rmsService.get(101)).thenReturn(room);

        when(rmsService.add(any(RoomManagement.class))).thenAnswer(invocation -> {
            RoomManagement updated = invocation.getArgument(0);
            updated.setRoomoccupancy("Occupied");
            return updated;
        });

        RoomManagement result = rmsController.updateRooms(101, updatedRoom);

        assertNotNull(result);
        assertEquals("Occupied", result.getRoomoccupancy());
        assertEquals(101, result.getRoomnumber());
        assertEquals("Deluxe", result.getRoomtype());
        assertEquals(2, result.getRoomsize());

        verify(rmsService, times(1)).get(101);
        verify(rmsService, times(1)).add(any(RoomManagement.class));
    }

    @Test
    void deleteRoomTest() {
        when(rmsService.get(101)).thenReturn(room);

        String result = rmsController.removeRoom(101);

        assertEquals("Room deleted Successfully", result);
        verify(rmsService, times(1)).get(101);
        verify(rmsService, times(1)).delete(room);
    }
}
